package com.finesi.neuronav

import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.finesi.neuronav.ui.screens.AppsScreen
import com.finesi.neuronav.ui.screens.FileExplorerScreen
import com.finesi.neuronav.ui.screens.HomeScreen
import com.finesi.neuronav.ui.screens.SearchScreen

@Composable
fun NeuroNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                onNavigateToFiles = {
                    navController.navigate("files")
                },
                onNavigateToApps = {
                    navController.navigate("apps")
                },
                onNavigateToSearch = {
                    navController.navigate("search")
                }
            )
        }

        composable("files") {
            FileExplorerScreen(
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }

        composable("apps") {
            AppsScreen(
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }

        composable("search") {
            SearchScreen(
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }
    }
}