package com.finesi.neuronav.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.finesi.neuronav.ui.theme.*
import com.finesi.neuronav.utils.FileUtils
import com.finesi.neuronav.utils.PermissionHelper
import java.io.File
import android.os.Environment

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileExplorerScreen(
    onBackClick: () -> Unit = {}
) {
    val context = LocalContext.current
    var currentDirectory by remember { mutableStateOf<File?>(null) }
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    var directoryHistory by remember { mutableStateOf<List<File>>(emptyList()) }

    // Cargar directorio inicial
    LaunchedEffect(Unit) {
        // Mostrar directorios principales del teléfono
        val mainDirectories = mutableListOf<File>()

        // Agregar almacenamiento principal
        val storage = Environment.getExternalStorageDirectory()
        if (storage.exists()) {
            mainDirectories.add(storage)
        }

        // Agregar carpetas específicas más accesibles
        val publicDirs = mapOf(
            "Descargas" to Environment.DIRECTORY_DOWNLOADS,
            "Fotos" to Environment.DIRECTORY_PICTURES,
            "Cámara" to Environment.DIRECTORY_DCIM,
            "Videos" to Environment.DIRECTORY_MOVIES,
            "Música" to Environment.DIRECTORY_MUSIC,
            "Documentos" to Environment.DIRECTORY_DOCUMENTS
        )

        publicDirs.forEach { (name, dirType) ->
            try {
                val dir = Environment.getExternalStoragePublicDirectory(dirType)
                if (dir?.exists() == true) {
                    mainDirectories.add(dir)
                }
            } catch (e: Exception) {
                // Ignorar si no se puede acceder
            }
        }

        // Si tenemos directorios, mostrar el primero (que es el almacenamiento principal)
        if (mainDirectories.isNotEmpty()) {
            currentDirectory = mainDirectories.first()
            files = FileUtils.getFilesInDirectory(mainDirectories.first())
        }
    }

    // Función para navegar a un directorio
    fun navigateToDirectory(directory: File) {
        currentDirectory?.let { current ->
            directoryHistory = directoryHistory + current
        }
        currentDirectory = directory
        files = FileUtils.getFilesInDirectory(directory)
    }

    // Función para ir atrás
    fun goBack() {
        if (directoryHistory.isNotEmpty()) {
            val previousDirectory = directoryHistory.last()
            directoryHistory = directoryHistory.dropLast(1)
            currentDirectory = previousDirectory
            files = FileUtils.getFilesInDirectory(previousDirectory)
        } else {
            onBackClick()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        DarkBackground,
                        DarkSurface.copy(alpha = 0.8f),
                        DarkBackground
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header con botones de navegación
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = DarkCard
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { goBack() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Atrás",
                            tint = NeuroBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            // Ir al directorio raíz del almacenamiento
                            val rootDir = Environment.getExternalStorageDirectory()
                            currentDirectory = rootDir
                            files = FileUtils.getFilesInDirectory(rootDir)
                            directoryHistory = emptyList()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Raíz",
                            tint = NeuroGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            PermissionHelper.requestAllFilesAccess(context)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Permisos",
                            tint = NeuroOrange,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "EXPLORADOR NEURAL",
                            color = NeuroGreen,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = currentDirectory?.name ?: "Cargando...",
                            color = TextSecondary,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "${files.size} elementos",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Lista de archivos
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(files) { file ->
                    FileItem(
                        file = file,
                        onClick = {
                            if (file.isDirectory) {
                                navigateToDirectory(file)
                            } else {
                                FileUtils.openFile(context, file)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun FileItem(
    file: File,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(
                width = 1.dp,
                color = if (file.isDirectory) NeuroBlue.copy(alpha = 0.3f) else NeuroGreen.copy(alpha = 0.3f),
                shape = RoundedCornerShape(8.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = DarkCard.copy(alpha = 0.7f)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icono
            Text(
                text = FileUtils.getFileIcon(file),
                fontSize = 24.sp,
                modifier = Modifier.size(32.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Información del archivo
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = file.name,
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )

                if (!file.isDirectory) {
                    Text(
                        text = "${FileUtils.formatFileSize(file.length())} • ${FileUtils.formatDate(file.lastModified())}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                } else {
                    val itemCount = try {
                        file.listFiles()?.size ?: 0
                    } catch (e: Exception) {
                        0
                    }
                    Text(
                        text = "$itemCount elementos",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            // Indicador visual
            if (file.isDirectory) {
                Icon(
                    imageVector = Icons.Default.Folder,
                    contentDescription = null,
                    tint = NeuroBlue,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.InsertDriveFile,
                    contentDescription = null,
                    tint = NeuroGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}